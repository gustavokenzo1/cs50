# export API_KEY=pk_21f9aab4b99f427d81f18978e64c2597

import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # Select symbol and number of shares to complete user's portifolio
    stocks = db.execute("SELECT symbol, shares FROM portifolio WHERE id = ?", session["user_id"])

    # initiate a variable to store total cash of user
    total = 0

    # iterate through every stock and assign their symbol, name, shares and price to a variable
    # while also counting the total cash
    for row in stocks:
        symbol = row["symbol"]
        name = lookup(symbol)["name"]
        shares = float(row["shares"])
        price = float(lookup(symbol)["price"])
        total_stock = price*shares
        row["name"] = name
        row["symbol"] = symbol
        row["price"] = usd(price)
        row["total"] = usd(total_stock)
        total = total + total_stock

    # get user's current cash and add it to the total cash invested in stocks
    usable_cash = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])[0]["cash"]
    stock_sum = usable_cash + total

    return render_template("index.html", stock_sum=usd(stock_sum), usable_cash=usd(usable_cash), stocks=stocks)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    if request.method == "POST":

        # If the user didn't type any symbol nor any number, return error
        if (not request.form.get("shares")) or (not request.form.get("symbol")):
            return apology("not stonks")

        stock = lookup(request.form.get("symbol"))

        # If there is no information about the stock, then it doesn't exist, return error
        if stock == None:
            return apology("Stock doesn´t exist", 400)

        # Check if the user typed an integer
        try:
            shares = int(request.form.get("shares"))
        except:
            return apology("You must provide an integer number",400)

        # If the user typed a number smaller than 1, return error
        if int(shares) <= 0:
            return apology("do you even want to buy?")

        stock_name = stock["symbol"]
        stock_price = stock["price"]

        user_cash = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])

        # Get total cost of stocks
        total = float(stock_price) * float(shares)

        if float(user_cash[0]["cash"]) < total:
            return apology("too poor")

        else:
            current_cash = float(user_cash[0]["cash"]) - total
            operation = "Buy"

            # Update user's cash
            db.execute("UPDATE users SET cash = ? WHERE id = ?", current_cash, session["user_id"])

            # Put everything in user's history
            db.execute("INSERT INTO history (id, operation, symbol, price, shares, time) VALUES (?, ?, ?, ?, ?, ?)",
                       session["user_id"], operation, stock_name, stock_price, shares, datetime.now().strftime("%m-%d-%Y %H:%M"))

            # Put almost everything in user's portifolio
            db.execute("INSERT INTO portifolio (id, symbol, shares) VALUES (?, ?, ?)", session["user_id"], stock_name, shares)

            return redirect("/")
    else:
        return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""

    # Get user's information from HISTORY table ordering it by time
    stocks = db.execute(
        "SELECT operation, symbol, price, shares, time FROM history WHERE id = ? ORDER BY time DESC", session["user_id"])

    for row in stocks:
        symbol = row["symbol"]
        shares = row["shares"]
        operation = row["operation"]
        time = row["time"]
        name = lookup(symbol)["name"]
        price = lookup(symbol)["price"]
        row["name"] = name
        row["symbol"] = symbol
        row["price"] = usd(price)
        row["operation"] = operation
        row["time"] = time
        row["shares"] = shares

    if not stocks:
        return apology("Not stonks")

    return render_template("history.html", stocks=stocks)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":

        quote = lookup(request.form.get("symbol"))

        if quote == None:
            return apology("Not Stonks", 400)

        return render_template("quoted.html", name=quote["name"], symbol=quote["symbol"], price=usd(quote["price"]))

    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":

        # Get user's username and do all the necessary checks
        if not request.form.get("username"):
            return apology("You must type an username")

        elif not request.form.get("password"):
            return apology("You must type a password")

        elif not request.form.get("confirmation"):
            return apology("You must confirm your password")

        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("Passwords don't match")

        # Optinal check from the problem set, password must have at least 8 characters and one number
        elif len(request.form.get("password")) < 8:
            return apology("Password must have at least 8 characters")

        elif not any(i.isdigit() for i in request.form.get("password")):
            return apology("Password must contain at least one digit")

        # Check if username already exists
        row = db.execute("SELECT * FROM users WHERE username = :username", username=request.form.get("username"))
        if len(row) >= 1:
            return apology("This username already exists")

        username = request.form.get("username")
        hash = generate_password_hash(request.form.get("password"))

        # Insert user into database if everything goes right
        db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", username, hash)

        return render_template("login.html")

    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    if request.method == "POST":

        symbol = request.form.get("symbol")
        shares = request.form.get("shares")
        symbol = symbol.upper()

        if not symbol:
            return apology("Not stonks. Symbol doesn't exist.")

        if not shares:
            return apology("not stonks. you didn't type shares")

        # Check how many shares user has
        owned_shares = db.execute("SELECT shares FROM portifolio WHERE symbol = ? AND id = ?",
                                  symbol, session["user_id"])[0]["shares"]

        # If user doesn't have enough shares, return error
        if int(owned_shares) < int(shares):
            return apology("Not stonks. You don't have that much shares.")

        else:
            # Get stock's price and multiply by number of shares to get the total cash
            stock = lookup(request.form.get("symbol"))
            stock_price = float(stock["price"])

            cash = stock_price * float(shares)
            operation = "Sell"

            # Get user's cash prior to selling, so we can add them
            prev_cash = db.execute("SELECT cash FROM users WHERE id = ?", session["user_id"])[0]["cash"]
            money = float(prev_cash) + cash
            updated_shares = int(owned_shares) - int(shares)

            # Update user's cash
            db.execute("UPDATE users SET cash = ? WHERE id = ?", money, session["user_id"])

            # Update user's history
            db.execute("INSERT INTO history (id, operation, symbol, price, shares, time) VALUES (?, ?, ?, ?, ?, ?)",
                       session["user_id"], operation, symbol, stock_price, shares, datetime.now().strftime("%m-%d-%Y %H:%M"))

            # If user didn't sell all his or her shares, we want it to keep displaying on portifolio
            if updated_shares > 0:
                db.execute("UPDATE portifolio SET shares = ? WHERE id = ?", updated_shares, session["user_id"])

            # If user sold all his or her shares, we want to delete the information from portifolio
            else:
                db.execute("DELETE FROM portifolio WHERE id = ? AND symbol = ?", session["user_id"], symbol)

        return redirect("/")

    else:

        symbols = db.execute("SELECT symbol FROM portifolio WHERE id = ?", session["user_id"])
        return render_template("sell.html", symbols=symbols)


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
